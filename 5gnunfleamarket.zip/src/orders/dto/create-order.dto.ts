export class CreateOrderDto {
  readonly price: number;
}
