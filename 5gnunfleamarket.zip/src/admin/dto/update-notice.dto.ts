
import { CreateNoticeDto } from './create-notice.dto';

export class UpdateNoticeDto extends CreateNoticeDto {}
